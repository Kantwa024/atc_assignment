```
import atcSimuKantwa.ui as Ui
Ui.Ui()
```
