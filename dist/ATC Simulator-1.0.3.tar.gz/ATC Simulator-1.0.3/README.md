```
import atcSimulator.ui as Ui
Ui.Ui()
```
